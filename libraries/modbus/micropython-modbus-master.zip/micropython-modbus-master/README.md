# micropython-modbus
Modbus Master library for MicroPython ESP32 devices. Based on pycom-modbus from pycom: https://github.com/pycom/pycom-modbus/
